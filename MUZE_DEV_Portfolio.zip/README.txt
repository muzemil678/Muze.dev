MUZE.DEV PORTFOLIO
===================

FILES
- index.html: page structure and content
- style.css: black/orange responsive design
- script.js: mobile navigation, scroll effects, language switcher, email contact form
- assets/muzemil.jpg: your supplied portrait

HOW TO OPEN ON ANDROID
1. Extract the ZIP file using your file manager.
2. Open the extracted folder in your preferred code editor (Spck Editor, Acode, or another HTML editor).
3. Open index.html in the editor's preview/browser.
4. Keep index.html, style.css, script.js, and the assets folder together.

IMPORTANT
- The contact form opens the visitor's email app; it does not save messages to a database.
- The project artwork is illustrative. Replace it with real screenshots and add live project links when available.
- WhatsApp currently links to the first phone number supplied. Confirm the country-code formatting and preferred number before publishing.
- This is a static site. You can publish it later on GitHub Pages or Netlify.
- Fonts load from Google Fonts when internet is available; fallback fonts are included.
