const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');
menuToggle.addEventListener('click', () => {
  const opened = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(opened));
  menuToggle.textContent = opened ? '×' : '☰';
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.textContent = '☰';
}));

const progressBar = document.getElementById('progressBar');
window.addEventListener('scroll', () => {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  progressBar.style.width = (max > 0 ? window.scrollY / max * 100 : 0) + '%';
});

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
document.getElementById('year').textContent = new Date().getFullYear();

const translations = {
  en: {
    navHome:'Home',navAbout:'About',navSkills:'Skills',navProjects:'Projects',navContact:'Contact',
    eyebrow:'DIGITAL CREATOR · DEVELOPER',heroTitle:'I build digital<br><span>experiences.</span>',
    heroIntro:"I'm Muzemil Abduljebar — a web developer, video editor and graphic designer focused on creating useful, modern digital experiences.",
    viewWork:'Explore my work',hireMe:"Let's work together",based:'Based in Ethiopia',scroll:'SCROLL TO EXPLORE',
    aboutLabel:'ABOUT ME',aboutTitle:'Curiosity into<br><span>digital craft.</span>',aboutLead:'I combine technology and creativity to turn ideas into practical digital products.',
    aboutText:'My work spans website development, visual design and video editing. I enjoy learning, solving problems and building projects that help people and businesses present themselves online.',
    startProject:"Have a project in mind? Let's talk",skillsLabel:'WHAT I DO',skillsTitle:'Creative thinking.<br><span>Technical skills.</span>',
    webDev:'Website Development',webDesc:'Responsive websites built with a focus on clarity, speed and usability.',videoEdit:'Video Editing',videoDesc:'Short-form content and polished edits designed to hold attention.',
    graphicDesign:'Graphic Design',graphicDesc:'Visual assets that give brands a consistent and memorable look.',selectedWork:'SELECTED WORK',
    projectsTitle:'Ideas in <span>action.</span>',projectsIntro:'A selection of projects and concepts I have been building.',conceptProject:'EDTECH CONCEPT',
    aiDesc:'An educational AI tutor concept designed to help Grade 12 students practise and learn.',webPlatform:'ONLINE LEARNING PLATFORM',
    academyDesc:'A learning platform concept for digital skills and online courses.',schoolWebsite:'SCHOOL WEBSITE',
    schoolDesc:'A multilingual school website concept for sharing school information and updates.',designWork:'WEB & VISUAL DESIGN',
    businessProjects:'Business Websites & Graphics',businessDesc:'A showcase area for commercial website, logo, poster and banner work.',
    projectNote:'Project previews are illustrative. Add real screenshots and live links as each project becomes ready to showcase.',
    ctaTitle:'Your idea deserves<br><span>a great digital home.</span>',contactMe:'Contact me',contactLabel:'GET IN TOUCH',
    contactTitle:"Let's make it <span>happen.</span>",contactIntro:'Have a website, design or video project? Tell me what you have in mind.',
    yourName:'Your name',yourEmail:'Your email',serviceNeeded:'What do you need?',yourMessage:'Tell me about your project',
    sendMessage:'Send message',formNote:'This opens your email app with your message ready to send.',
    footerLine:'Built with curiosity and creativity.',backTop:'Back to top'
  },
  om: {
    navHome:'Jalqaba',navAbout:'Waa’ee Koo',navSkills:'Dandeettii',navProjects:'Hojiiwwan',navContact:'Na Quunnami',
    eyebrow:'UUMAA DIJITAALAA · DEVELOPER',heroTitle:'Ani muuxannoo<br><span>dijitaalaa uuma.</span>',
    heroIntro:'Ani Muzemil Abduljebar — web developer, video editor fi graphic designer dha. Teknooloojii fi kalaqa walitti fiduun hojii dijitaalaa ammayyaa uuma.',
    viewWork:'Hojii koo ilaali',hireMe:'Waliin haa hojjennee',based:'Itoophiyaa keessa',scroll:'ILAALUUF GADI BU’I',
    aboutLabel:'WAA’EE KOO',aboutTitle:'Yaada gara<br><span>hojii dijitaalaatti.</span>',aboutLead:'Teknooloojii fi kalaqa walitti fiduun yaada gara oomisha dijitaalaa faayidaa qabuutti jijjiira.',
    aboutText:'Hojiiwwan koo website development, visual design fi video editing of keessatti qabata. Barachuu, rakkoo hiikuu fi namootaafi dhaabbileen hojii isaanii online irratti akka dhiyeessan gargaaru hojjechuun na gammachiisa.',
    startProject:'Pirojektii qabdaa? Na qunnami',skillsLabel:'WAA NAN HOJJADHU',skillsTitle:'Kalaqa fi<br><span>dandeettii teeknikaa.</span>',
    webDev:'Website Development',webDesc:'Website bilbilaafi kompiitara irratti sirriitti hojjetu, salphaa fi saffisaa.',videoEdit:'Video Editing',videoDesc:'Viidiyoo gabaabaa fi gulaallii nama hawwatu.',
    graphicDesign:'Graphic Design',graphicDesc:'Dizaayinii maqaa daldalaa ifaafi yaadatamu uumu.',selectedWork:'HOJIIWWAN FILATAMAN',
    projectsTitle:'Yaada gara <span>hojiitti.</span>',projectsIntro:'Fakkeenya pirojektoota ani ijaaruu irratti hojjechaa jiru.',conceptProject:'YAADA BARNOOTA TEKNOOLOOJII',
    aiDesc:'Yaada AI tutor barattoonni kutaa 12ffaa shaakaluufi barachuuf gargaaru.',webPlatform:'PLATFORMII BARNOOTAA',
    academyDesc:'Platformii dandeettii dijitaalaa fi koorsii online barachuuf yaadame.',schoolWebsite:'WEBSITE MANA BARUMSAA',
    schoolDesc:'Website afaanota hedduu qabu kan odeeffannoo mana barumsaa qooduuf yaadame.',designWork:'WEBSITE FI DIZAAYINII',
    businessProjects:'Website Daldalaa fi Graphics',businessDesc:'Website daldalaa, logo, poster fi banner hojii agarsiisuuf iddoo.',
    projectNote:'Suuraaleen pirojektii kun fakkeenya agarsiisaati. Yeroo hojiiwwan qophaa’an screenshot fi linkii dhugaa itti dabali.',
    ctaTitle:'Yaadni kee iddoo<br><span>dijitaalaa bareedaa haa qabaatu.</span>',contactMe:'Na qunnami',contactLabel:'WALITTI DHUFNEE',
    contactTitle:'Waan gaarii <span>haa hojjennu.</span>',contactIntro:'Website, dizaayinii yookaan viidiyoo barbaaddaa? Yaada kee natti himi.',
    yourName:'Maqaa kee',yourEmail:'Email kee',serviceNeeded:'Tajaajila barbaaddu',yourMessage:'Waa’ee pirojektii kee natti himi',
    sendMessage:'Ergaa ergi',formNote:'Kun email kee bana; ergaa kee erguuf qopheessa.',
    footerLine:'Kalaqaa fi fedhii barachuutiin hojjetame.',backTop:'Gara gubbaatti'
  },
  am: {
    navHome:'الرئيسية',navAbout:'من أنا',navSkills:'المهارات',navProjects:'المشاريع',navContact:'تواصل معي',
    eyebrow:'مبدع رقمي · مطور',heroTitle:'أصنع تجارب<br><span>رقمية مميزة.</span>',
    heroIntro:'أنا مزمل عبد الجبار، مطور مواقع ومحرر فيديو ومصمم جرافيك، أركز على إنشاء تجارب رقمية حديثة ومفيدة.',
    viewWork:'استكشف أعمالي',hireMe:'لنعمل معًا',based:'إثيوبيا',scroll:'مرر للاستكشاف',
    aboutLabel:'نبذة عني',aboutTitle:'من الفضول إلى<br><span>الإبداع الرقمي.</span>',aboutLead:'أجمع بين التقنية والإبداع لتحويل الأفكار إلى منتجات رقمية عملية.',
    aboutText:'يشمل عملي تطوير المواقع والتصميم المرئي وتحرير الفيديو. أحب التعلم وحل المشكلات وبناء مشاريع تساعد الأفراد والشركات على الظهور عبر الإنترنت.',
    startProject:'لديك مشروع؟ لنتحدث',skillsLabel:'ماذا أقدم',skillsTitle:'تفكير إبداعي.<br><span>مهارات تقنية.</span>',
    webDev:'تطوير المواقع',webDesc:'مواقع متجاوبة تركز على الوضوح والسرعة وسهولة الاستخدام.',videoEdit:'تحرير الفيديو',videoDesc:'مقاطع قصيرة ومونتاج جذاب يحافظ على انتباه المشاهد.',
    graphicDesign:'التصميم الجرافيكي',graphicDesc:'تصاميم تمنح العلامات التجارية مظهرًا متناسقًا ولا يُنسى.',selectedWork:'أعمال مختارة',
    projectsTitle:'الأفكار تتحول إلى <span>إنجاز.</span>',projectsIntro:'مجموعة من المشاريع والأفكار التي أعمل على تطويرها.',conceptProject:'فكرة تعليمية تقنية',
    aiDesc:'فكرة مدرس ذكي بالذكاء الاصطناعي لمساعدة طلاب الصف الثاني عشر على التعلم والتدرب.',webPlatform:'منصة تعليم إلكتروني',
    academyDesc:'منصة لتعلم المهارات الرقمية والدورات عبر الإنترنت.',schoolWebsite:'موقع مدرسة',
    schoolDesc:'فكرة موقع متعدد اللغات لمشاركة معلومات المدرسة وتحديثاتها.',designWork:'تصميم مواقع وهوية بصرية',
    businessProjects:'مواقع تجارية وتصاميم',businessDesc:'مساحة لعرض مواقع الأعمال والشعارات والملصقات واللافتات.',
    projectNote:'معاينات المشاريع توضيحية. أضف لقطات شاشة وروابط حقيقية عندما تصبح المشاريع جاهزة للعرض.',
    ctaTitle:'فكرتك تستحق<br><span>واجهة رقمية رائعة.</span>',contactMe:'تواصل معي',contactLabel:'تواصل معي',
    contactTitle:'لنجعلها <span>حقيقة.</span>',contactIntro:'هل لديك مشروع موقع أو تصميم أو فيديو؟ أخبرني بفكرتك.',
    yourName:'اسمك',yourEmail:'بريدك الإلكتروني',serviceNeeded:'ما الخدمة التي تحتاجها؟',yourMessage:'أخبرني عن مشروعك',
    sendMessage:'إرسال الرسالة',formNote:'سيتم فتح تطبيق البريد برسالتك جاهزة للإرسال.',
    footerLine:'صُنع بالفضول والإبداع.',backTop:'العودة للأعلى'
  }
};
const languageSelect = document.getElementById('languageSelect');
languageSelect.addEventListener('change', () => {
  const dict = translations[languageSelect.value];
  document.documentElement.lang = languageSelect.value;
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    if (dict[key]) el.innerHTML = dict[key];
  });
  document.body.dir = languageSelect.value === 'am' ? 'rtl' : 'ltr';
  // Keep navigation and layout usable while switching languages.
});

document.getElementById('contactForm').addEventListener('submit', event => {
  event.preventDefault();
  const form = event.currentTarget;
  const name = form.name.value.trim();
  const email = form.email.value.trim();
  const service = form.service.value;
  const message = form.message.value.trim();
  const subject = encodeURIComponent(`Portfolio enquiry: ${service}`);
  const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nService: ${service}\n\nProject details:\n${message}`);
  window.location.href = `mailto:muzestudio@gmail.com?subject=${subject}&body=${body}`;
});
